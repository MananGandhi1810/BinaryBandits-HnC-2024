package com.example.binary_bandits_hnc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
